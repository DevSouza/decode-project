package com.ead.authuser.enums;

public enum CourseStatus {
    INPROGRESS,
    CONCLUDED;
}
