package com.ead.authuser.enums;

public enum RoleType {
    ROLE_STUDENT,
    ROLE_INSTRUCTOR,
    ROLE_ADMIN,
    ROLE_USER;
}
