package com.ead.course.services;

public interface UserService {

}
