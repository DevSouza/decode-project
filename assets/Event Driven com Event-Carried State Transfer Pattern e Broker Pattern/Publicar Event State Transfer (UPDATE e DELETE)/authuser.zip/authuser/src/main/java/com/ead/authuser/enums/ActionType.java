package com.ead.authuser.enums;

public enum ActionType {
    CREATE,
    UPDATE,
    DELETE;
}
