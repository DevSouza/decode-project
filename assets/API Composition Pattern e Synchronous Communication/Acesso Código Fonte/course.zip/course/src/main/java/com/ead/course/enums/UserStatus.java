package com.ead.course.enums;

public enum UserStatus {
    ACTIVE,
    BLOCKED;
}
