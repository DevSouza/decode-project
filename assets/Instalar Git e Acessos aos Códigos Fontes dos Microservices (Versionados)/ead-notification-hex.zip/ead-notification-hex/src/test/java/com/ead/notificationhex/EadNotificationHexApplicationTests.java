package com.ead.notificationhex;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EadNotificationHexApplicationTests {

    @Test
    void contextLoads() {
    }

}
