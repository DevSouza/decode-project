package com.ead.authuser;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AuthuserApplicationTests {

	@Test
	void contextLoads() {
	}

}
