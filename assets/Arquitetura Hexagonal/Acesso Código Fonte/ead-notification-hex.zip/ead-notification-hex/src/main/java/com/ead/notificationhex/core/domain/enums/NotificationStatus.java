package com.ead.notificationhex.core.domain.enums;

public enum NotificationStatus {
    CREATED,
    READ;
}
